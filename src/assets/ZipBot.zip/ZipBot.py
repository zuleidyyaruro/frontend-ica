import os
import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.edge.service import Service
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def descargar_documentos():
    service = Service(EdgeChromiumDriverManager().install())
    download_dir = os.getcwd()

    edge_options = webdriver.EdgeOptions()
    edge_options.add_experimental_option("prefs", {
        "download.default_directory": download_dir,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })

    edge_options.add_argument('--headless')
    edge_options.add_argument('--disable-gpu')
    
    driver = webdriver.Edge(service=service, options=edge_options)
    driver.set_page_load_timeout(30)

    df = pd.read_csv('municipios.csv')
    municipios_con_descarga = df[df['descargar'] == 'si']

    for index, row in municipios_con_descarga.iterrows():
        print("Descargando:"+row['municipio'])

        try:
            municipality: str = row['municipio']
            url = 'https://bancolombia.sharepoint.com/sites/co-dsf/Documentos%20compartidos/Forms/https___bancolombia.sharepoint.com_sites_co-dsf_Documentos_20compartidos_Forms_AllItems.aspx_id=_2Fsites_2Fco_2Ddsf_2FDocumentos_20compartidos_2FGSRLT&viewid=53e774a0_2Dbfd8_2D449e_2D8294_2Dc920095e982f.aspx?FolderCTID=0x0120004AC58A1A3B91D94D923C7B35E26F7603&id=%2Fsites%2Fco%2Ddsf%2FDocumentos%20compartidos%2FGSRLT%2FPortal%20de%20normas%2FAcuerdos%2Fmunicipality'
            url = url.replace('municipality', municipality.replace(' ', '%20') )
            driver.get(url)
        except Exception as e:
            print(f"Error al abrir la página: {e}")

        try:
            button = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, "/html/body/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div/div[1]/div[5]/button/span"))
            )
            button.click()
        except Exception as e:
            print("El botón no fue encontrado o no se pudo hacer clic:", e)

    while True:
        time.sleep(10)
        if not any(filename.endswith('.crdownload') for filename in os.listdir(download_dir)):
            break
        
    driver.quit()


if __name__ == "__main__":
    descargar_documentos()
   
